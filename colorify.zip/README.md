# CalorieCalculatorApp

## Prerequisites

pip3 install Django (version 3.0.2)
PyCharm (venv)


## Commits
### User login or register
### Firstly enter information to calorie calculation form
### Then take an API adress and open food calorie calculation form and fill
### You can see your daily calorie,food's calorie and remain calorie
### You can control database records using admin panel
### Finally, you logout or register again
