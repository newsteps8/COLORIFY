from django import forms
from .models import Post

class PostForm(forms.ModelForm):

    class Meta:
        model = Post
        fields = [
                  'title',
                  'cover',
                  ]
#form doldururken alınacak inputların bilgisi ve form objesi oluşturmak için class
