from django.shortcuts import render
import os
# posts/views.py
from django.shortcuts import render, HttpResponse, get_object_or_404, HttpResponseRedirect, redirect, Http404
from django.views.generic import ListView,CreateView
from .models import Post
from django.urls import reverse_lazy # new
from .forms import PostForm # new
from django.http import HttpResponse
from wsgiref.util import FileWrapper
from django.contrib import messages




def create_post(request): # renklendirilcek fotoğrafın gönderilecek olduğu sayfaya yönlendirir

    form = PostForm(request.POST or None,request.FILES )#form objesi oluşturur

    if form.is_valid():#form geçerli olursa kaydedilir
        post = form.save(commit=False)
        post.user = request.user
        post.save()
        messages.success(request, "You have successfully created it.", extra_tags='mesaj-basarili')
        return HttpResponseRedirect(post.get_absolute_url())
    context = {
        'form': form
    }

    return render(request, "post.html", context)#formun geleceği sayfa


def image_detail(request):#renklendirilmiş resmin olduğu sayfaya yönlendirir
    form = PostForm(request.POST , request.FILES)
    post = Post.objects.filter(user=request.user).order_by('id').last()#son kullanıcın girdiği "en son" resim ve string datalarını alır ve post objesi üzerinden datalarda değişiklik yapılır(fotoğrafın renklendirilmesi)

    if form.is_valid():#yukardakilerin aynısı
        comment = form.save(commit=False)
        comment.post = post
        comment.save()
        return HttpResponseRedirect(post.get_absolute_url)#modeldeki sayfaya yönlendirir

    context = { #detail.html sayfasında referans verilcek datalar burda tutulur
        'post': post,
        'form': form
    }
    return render(request, "detail.html", context)#sonuç sayfasına yönlendirir




def download_image(request):#resimi yükle
    form = PostForm(request.POST, request.FILES or None)
    post = Post.objects.filter(user=request.user).order_by('id').last()#yine en son dataları alır databaseden değişen data da databasee kaydedilmişti(renkli resim) onu da alır

    #filename = '../colorify/media/new2.jpg'
    #content = FileWrapper(open(filename, 'rb'))
    response = HttpResponse(post.new, content_type='application/jpg')#yeni resimin indirilmeden önce dosya tipi belirenir
    #response['Content-Length'] = os.path.getsize(filename)
    response['Content-Disposition'] = 'attachment; filename=%s' % post.title#form sayfasına girilen isimle birlikte resim dosyası indirilir
    return response