from django.conf import settings
import numpy as np
import cv2
from django.db import models
from django.urls import reverse
from django.core.files import File
from io import BytesIO
import os
from PIL import Image


#tüm inputların ve outputların databasee kaydolduğu ve renklendirmenin yapıldığı kısım
class Post(models.Model):
    user = models.ForeignKey('auth.User', related_name='postss',on_delete=models.CASCADE)
    publishing_date = models.DateTimeField(verbose_name="Date", auto_now_add=True)
    title = models.TextField(default = "enter title for your image")#resim için bilgi
    cover = models.ImageField(default = "choose your image from your computer")#seçilen resim
    new = models.ImageField()#değişmiş olan resimin kayıtlanacağı data


    class Meta:
        ordering = ['-publishing_date', 'id']#order datas

    def save(self, *args, **kwargs):
        #modelin datalarının database e kaydedildiği yer
        self.title = self.title
        self.cover = self.cover

        #cnn modelinin başladığı yer
        print("[INFO] loading model...")
        net = cv2.dnn.readNetFromCaffe("../bw-colorization/model/colorization_deploy_v2.prototxt",
                                       "../bw-colorization/model/colorization_release_v2.caffemodel")
        pts = np.load("../bw-colorization/model/pts_in_hull.npy")#pretrained model ve numpy dosyaları yüklenir

        # add the cluster centers as 1x1 convolutions to the model
        class8 = net.getLayerId("class8_ab")
        conv8 = net.getLayerId("conv8_313_rh")
        pts = pts.transpose().reshape(2, 313, 1, 1)
        net.getLayer(class8).blobs = [pts.astype("float32")]
        net.getLayer(conv8).blobs = [np.full([1, 313], 2.606, dtype="float32")]

        # load the input image from disk, scale the pixel intensities to the
        # range [0, 1], and then convert the image from the BGR to Lab color
        # space
        image = np.asarray(bytearray(self.cover.read()), dtype="uint8")#alınan input imagei cv için ön işlemden geçiriyoruz
        image_encode = cv2.imdecode(image, cv2.IMREAD_COLOR)
        scaled = image_encode.astype("float32") / 255.0
        lab = cv2.cvtColor(scaled, cv2.COLOR_BGR2LAB)

        # resize the Lab image to 224x224 (the dimensions the colorization
        # network accepts), split channels, extract the 'L' channel, and then
        # perform mean centering
        resized = cv2.resize(lab, (224, 224))
        L = cv2.split(resized)[0]
        L -= 50

        # pass the L channel through the network which will *predict* the 'a'
        # and 'b' channel values
        'print("[INFO] colorizing image...")'
        net.setInput(cv2.dnn.blobFromImage(L))
        ab = net.forward()[0, :, :, :].transpose((1, 2, 0))

        # resize the predicted 'ab' volume to the same dimensions as our
        # input image
        ab = cv2.resize(ab, (image_encode.shape[1], image_encode.shape[0]))

        # grab the 'L' channel from the *original* input image (not the
        # resized one) and concatenate the original 'L' channel with the
        # predicted 'ab' channels
        L = cv2.split(lab)[0]
        colorized = np.concatenate((L[:, :, np.newaxis], ab), axis=2)

        # convert the output image from the Lab color space to RGB, then
        # clip any values that fall outside the range [0, 1]
        colorized = cv2.cvtColor(colorized, cv2.COLOR_LAB2BGR)
        colorized = np.clip(colorized, 0, 1)

        # the current colorized image is represented as a floating point
        # data type in the range [0, 1] -- let's convert to an unsigned
        # 8-bit integer representation in the range [0, 255]
        colorized = (255 * colorized).astype("uint8")

        # show the original and output colorized images

        cv2.imwrite('media/new2.jpg', colorized)#save new image
        self.new = "new2.jpg"
        super(Post, self).save(*args, **kwargs)


    def get_absolute_url(self):#sonuçların dönüleceği sayfaya yönlendirir
        return reverse('posts:imageDetail')


