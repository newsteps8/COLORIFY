from django.urls import path
from .views import *
from django.conf.urls import url



app_name = "posts"

urlpatterns = [

    path('post/', create_post, name='post'), # new
    path('detail/', image_detail, name='imageDetail'), # new
    url('download_my_image', download_image),
]

#view.py dosyasındaki fonksiyonlar ortadakiler, urller bu fonksiyonların döndürdüğü sayfalarla bağlantısını kurar