from django.conf.urls import url, include
from django.contrib import admin
from home.views import home_view, contact_view, sample_view, home_notlogin
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings # new
from django.urls import path, include # new
from django.conf.urls.static import static # new
from django.conf import settings


urlpatterns = [

    url(r'^$', home_view, name='home'),
    url(r'^home_notlogin/', home_notlogin, name='home_notlogin'),
    url(r'^contact/', contact_view, name='contact'),
    url(r'^sample/', sample_view, name='sample'),
    url(r'^accounts/', include('accounts.urls')),
    url(r'^white/', include('white.urls')),
    url(r'^admin/', admin.site.urls),
    path('admin/', admin.site.urls),
    path('posts/', include('posts.urls')), # new
]
urlpatterns += staticfiles_urlpatterns()
if settings.DEBUG: # new
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

