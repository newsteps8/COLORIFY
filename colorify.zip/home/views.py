from django.shortcuts import render, HttpResponse

def home_view(request):
    if request.user.is_authenticated:#kullanıcı login yaptıysa
        context = {
            'isim': 'Busra',
        }
    else:#yapmadıysa
        context = {
            'isim': 'Misafir Kullanıcı'
        }
    return render(request, 'home.html', context)#home sayfasına yönlendirir

def home_notlogin(request):#giriş yapmayan kullanıcılar için home sayfasına yönlendirir
    if request.user.is_authenticated:
        context = {
            'isim': 'Busra',
        }
    else:
        context = {
            'isim': 'Misafir Kullanıcı'
        }
    return render(request, 'home_notlogin.html', context)

def contact_view(request):#contact sayfasına yönlendirir
    if request.user.is_authenticated:
        context = {
            'isim': 'Busra',
        }
    else:
        context = {
            'isim': 'Misafir Kullanıcı'
        }
    return render(request, 'contact.html', context)

def sample_view(request):#sample sayfasına yönlendirir
        if request.user.is_authenticated:
            context = {
                'isim': 'Busra',
            }
        else:
            context = {
                'isim': 'Misafir Kullanıcı'
            }
        return render(request, 'form.html', context)
