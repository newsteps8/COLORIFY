from django.shortcuts import render, redirect
from .forms import LoginForm, RegisterForm
from django.contrib.auth import authenticate, login, logout


def login_view(request):
    # if this is a POST request we need to process the form data
    form = LoginForm(request.POST or None)# create a form instance and populate it with data from the request:
    # check whether it's valid:
    if form.is_valid():
        # process the data in form.cleaned_data as required
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password')
        user = authenticate(username=username, password=password)
        login(request, user)
        # redirect to home URL:
        return redirect('home')

    return render(request, "accounts/form.html", {"form": form, 'title': 'Login'})


def register_view(request):
    form = RegisterForm(request.POST or None)
    if form.is_valid():
        user = form.save(commit=False)
        password = form.cleaned_data.get('password1')
        user.set_password(password)
        user.save()#user is saved in database
        new_user = authenticate(username=user.username, password=password)
        login(request, new_user)
        return redirect('home')

    return render(request, "accounts/form.html", {"form": form, 'title': 'Sign Up'})


def logout_view(request):#redirect to home when logout
    logout(request)
    return redirect('home_notlogin')
