from django.conf.urls import url
from .views import *

app_name = "accounts"

urlpatterns = [

    url(r'^login/$', login_view, name="login"),#login sayfasına yönendirir

    url(r'^register/$', register_view, name="register"),#register sayfasına yönlendirir

    url(r'^logout/$', logout_view, name="logout"),#logout sayfasına yönlendirir

]

#view.py dosyasındaki fonksiyonlar ortadakiler, urller bu fonksiyonların döndürdüğü sayfalarla bağlantısını kurar