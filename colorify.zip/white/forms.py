from django import forms
from .models import White



class WhiteForm(forms.ModelForm):

    class Meta:
        model = White
        fields = [
                  'name_image',
                  'color_image',
                  ]
