from django.urls import path
from .views import *
from django.conf.urls import url



app_name = "white"

urlpatterns = [

    url(r'^bw/$', create_bw, name='bw_post'),
    url(r'^bwimage/$', bw_detail, name='BwDetail'),
    url('download_my_image', download_image),

]
