from django.apps import AppConfig


class WhiteConfig(AppConfig):
    name = 'white'#app
