
from django.contrib import admin

from .models import White




admin.site.register(White) #admin erişimi post modele

# Register your models here.
