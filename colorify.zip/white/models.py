from django.conf import settings
import numpy as np
import cv2
from django.db import models
from django.urls import reverse
from django.core.files import File
from io import BytesIO
import os
from PIL import Image

class White(models.Model):
    user = models.ForeignKey('auth.User', related_name='bw',on_delete=models.CASCADE)
    publishing_date = models.DateTimeField(verbose_name="Date", auto_now_add=True)
    name_image = models.TextField(default = "enter title for your image")#resim için bilgi
    color_image = models.ImageField(default = "choose your image from your computer")#seçilen resim
    new_image = models.ImageField()#değişmiş olan resimin kayıtlanacağı data

    class Meta:
        ordering = ['-publishing_date', 'id']#order datas


    def save(self, *args, **kwargs):
        self.name_image = self.name_image
        self.color_image = self.color_image


        image2 = np.asarray(bytearray(self.color_image.read()), dtype="uint8")#alınan resmi dosya olarak okur ve numpy arraye çevirir

        image_encode = cv2.imdecode(image2, cv2.IMREAD_GRAYSCALE)#resmi siyah beyaza çevirir(tabi burdaki kodun teknik olarak nasıl çalıştığını anlatsak güzel olur)
        #resmi daha sonra decode eder ve kaydeder

        cv2.imwrite('media/pht.jpg', image_encode)  # save new image
        self.new_image="pht.jpg"#burda da yeni resmi database e kaydeder
        super(White, self).save(*args, **kwargs)

    def get_absolute_url(self):#sonuçların dönüleceği sayfaya yönlendirir
        return reverse('white:BwDetail')


    #aslında white appinde tapılan herşey cv modeli hariç posts appindekierin aynısı