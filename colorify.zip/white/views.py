from django.shortcuts import render
import os
# posts/views.py
from django.shortcuts import render, HttpResponse, get_object_or_404, HttpResponseRedirect, redirect, Http404
from django.views.generic import ListView,CreateView
from .models import White
from django.urls import reverse_lazy # new
from .forms import WhiteForm # new
from django.http import HttpResponse
from wsgiref.util import FileWrapper
from django.contrib import messages

def create_bw(request): # new

    form = WhiteForm(request.POST or None, request.FILES)

    if form.is_valid():
        post = form.save(commit=False)
        post.user = request.user
        post.save()
        messages.success(request, "You have successfully created it.", extra_tags='mesaj-basarili')
        return HttpResponseRedirect(post.get_absolute_url())
    context = {
        'form': form
    }

    return render(request, "post2.html", context)

def bw_detail(request):
    form = WhiteForm(request.POST , request.FILES)
    black = White.objects.filter(user=request.user).order_by('id').last()

    if form.is_valid():
        comment = form.save(commit=False)
        comment.black= black
        comment.save()
        return HttpResponseRedirect(black.get_absolute_url)

    context = {
        'black': black,
        'form': form
    }
    return render(request, "detail2.html", context)


def download_image(request):
    form = WhiteForm(request.POST, request.FILES or None)
    black = White.objects.filter(user=request.user).order_by('id').last()

    #filename = '../colorify/media/aura.jpg'
    # content = FileWrapper(open(filename, 'rb'))
    response = HttpResponse(black.new_image, content_type='application/jpg')
    # response['Content-Length'] = os.path.getsize(filename)
    response['Content-Disposition'] = 'attachment; filename=%s' % black.name_image
    return response
